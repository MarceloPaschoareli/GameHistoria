package gameHistoria.name;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GameHistoriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GameHistoriaApplication.class, args);
	}

}
